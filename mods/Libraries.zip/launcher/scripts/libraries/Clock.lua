Launcher.Clock = {}

Launcher.Clock.SetHideDuration = function(Time)
    Launcher.Mem.WriteByte(0x7BD8A8,Time)
end
Launcher.Clock.HideDuration = function()
    return Launcher.Mem.Byte(0x7BD8A8)
end

Launcher.Clock.SetDisplayDuration = function(Time)
    Launcher.Mem.WriteByte(0x7BD8AC,Time)
end
Launcher.Clock.DisplayDuration = function()
    return Launcher.Mem.Byte(0x7BD8AC)
end
Launcher.Clock.SetDisplayPowerPlaySeconds = function()
    return Launcher.Mem.Byte(0x7BD8B0)
end
Launcher.Clock.DisplayPowerPlaySeconds = function()
    return Launcher.Mem.Byte(0x7BD8B0)
end
Launcher.Clock.Shown = function()
	if Launcher.Mem.Byte(0x7bd8a4) == 1 then
		return true
	else
		return false
	end
end