--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]


Launcher.Game = {}


Launcher.Game.Quit = function ()
	Launcher.Mem.WriteByte(0x415df5,2)
end
Launcher.Game.Period = function ()
	return Launcher.Mem.Byte(0x79BA38) + 1
end
Launcher.Game.SetPeriod = function (Period)
	Launcher.Mem.WriteByte(0x79BA38,Period - 1)
	Launcher.Mem.WriteByte(0x79BA3A,Period - 1)
end
Launcher.Game.Time = function ()
	return Launcher.Mem.Short(0x79BA34)
end
Launcher.Game.TimeMS = function(TicksPerSecond) -- Parameter is optional
    local Ticks = Launcher.Mem.Short(0x79ba36)
    if Ticks == 0 then
        return 0
    end
    if TicksPerSecond == nil then
        TicksPerSecond = 20 --Launcher.GameOption.PeriodTime()
    end
    local Div = TicksPerSecond/(Ticks)
    return math.floor(900/Div)
end
Launcher.Game.SetTime = function (Seconds)
	Launcher.Mem.WriteShort(0x79BA34, Seconds)
end
Launcher.Game.PuckPossessionTime = function()
    return Launcher.Mem.Long(0x79d330)
end
Launcher.Game.GoalieCoverTime = function()
    return Launcher.Mem.Long(0x79c82c)
end
Launcher.Game.SetGoalieCoverTime = function(Time)
    return Launcher.Mem.WriteLong(0x79c82c, Time)
end
Launcher.Game.SetFightsPerGame = function (Fights)
	Launcher.Mem.WriteByte(0x4A0DEA,Fights)
end
Launcher.Game.FightsPerGame = function ()
	return Launcher.Mem.Byte(0x4A0DEA)
end
Launcher.Game.InFaceoff = function ()
	
    if Launcher.Mem.Byte(0x7bcc98) == 1 then
		return true
	else
		return false
	end
end
Launcher.Game.InCutscene = function ()
    if Launcher.Mem.Byte(0x7BC958) ~= -1 then
		return true
	else
		return false
	end
end
Launcher.Game.Paused = function ()
	if Launcher.Mem.Byte(0x791118) == 1 then
		return true
	else
		return false
	end
end
Launcher.Game.StopPlay = function ()
    local Address
    Address = Launcher.Mem.Long(0x79CAB8)
    Launcher.Mem.WriteByte(Address+7,1)
end
Launcher.Game.PlayStopped = function ()
	if Launcher.Mem.Byte(0x79BA46) == 1 then
		return true
	else
		return false
	end
end
Launcher.Game.Loading = function ()
	if Launcher.Mem.Byte(0x7AAF24) == 1 then
		return true
	else
		return false
	end
end
Launcher.Game.InReplay = function ()
	if Launcher.Mem.Byte(0x78E5B8) == 1 then
		return true
	else
		return false
	end
end
Launcher.Game.Intermission = function ()
	if Launcher.Mem.Byte(0x76D240) == 1 then
		return true
	else
		return false
	end
end
Launcher.Game.PenaltyPending = function ()
	if Launcher.Mem.Byte(0x79B9BC) == 1 then
		return true
	else
		return false
	end
end
Launcher.Game.AwaySiren = function ()
	if Launcher.Mem.Byte(0x7C8A30) == 1 then
		return true
	else
		return false
	end
end
Launcher.Game.HomeSiren = function ()
	if Launcher.Mem.Byte(0x7C8A31) == 1 then
		return true
	else
		return false
	end
end
Launcher.Game.AwayTeamID = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Long(0x7a8e04)
    else
        Launcher.Mem.WriteLong(0x7a8e04, NewValue)
    end
end
Launcher.Game.AwayTeamPBP = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Long(0x7a8e08)
    else
        Launcher.Mem.WriteLong(0x7a8e08, NewValue)
    end
end
Launcher.Game.AwayTeamArt = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Long(0x7a8e0c)
    else
        Launcher.Mem.WriteLong(0x7a8e0c, NewValue)
    end
end
Launcher.Game.AwayNameAbbreviation = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.String(0x7a8e30)
    else
        Launcher.Mem.WriteString(0x7a8e30,NewValue)
    end
end
Launcher.Game.AwayFullName = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.String(0x7a8e14)
    else
        Launcher.Mem.WriteString(0x7a8e14,NewValue)
    end
end
Launcher.Game.AwayShortName = function (NewValue)
    if NewValue == nil then    
        return Launcher.Mem.String(0x7a8e38)
    else
        Launcher.Mem.WriteString(0x7a8e38,NewValue)
    end
end

Launcher.Game.AwaySelectedPlayer = function()
    return Launcher.Mem.Byte(0x79BDB6)
end
Launcher.Game.HomeTeamID = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Long(0x7A875C)
    else
        Launcher.Mem.WriteLong(0x7A875C,NewValue)
    end
end
Launcher.Game.HomeTeamPBP = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Long(0x7A8760)
    else
        Launcher.Mem.WriteLong(0x7A8760,NewValue)
    end
end
Launcher.Game.HomeTeamArt = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Long(0x7A8764)
    else
        Launcher.Mem.WriteLong(0x7A8764,NewValue)
    end
end
Launcher.Game.HomeFullName = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.String(0x7a876c)
    else
        Launcher.Mem.WriteString(0x7a876c,NewValue)
    end
end
Launcher.Game.HomeShortName = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.String(0x7a8790)
    else
        Launcher.Mem.WriteString(0x7a8790,NewValue)
    end
end
Launcher.Game.HomeNameAbbreviation = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.String(0x7a8788)
    else
        Launcher.Mem.WriteString(0x7a8788,NewValue)
    end
end
Launcher.Game.HomeSelectedPlayer = function()
    return Launcher.Mem.Byte(0x79bc7e)
end
Launcher.Game.PlayerWithPuck = function ()
	return Launcher.Mem.Byte(0x79BEF4)
end
Launcher.Game.PlayerWithPuckRosterPointer = function()
    return Launcher.Mem.Long(0x79bad8)
end
Launcher.Game.LastPlayerWithPuckRosterPointer = function()
    return Launcher.Mem.Long(0x79c244)
end
Launcher.Game.TeamWithPuck = function ()
	return Launcher.Mem.Byte(0x79BAF8)
end
Launcher.Game.ShotSpeed = function ()
	return Launcher.Mem.String(0x79CABC)
end
Launcher.Game.ControllerTeam = function(Controller)
    return Launcher.Mem.Byte(0x78ea54+Controller*2)
end
Launcher.Game.HomeLeague = function ()
    return Launcher.Mem.Byte(0x776c61)
end
Launcher.Game.HomeStrategy = function ()
	return Launcher.Mem.Byte(0x7A8DF7)
end
Launcher.Game.SetHomeStrategy = function (Value)
	Launcher.Mem.WriteByte(0x7A8DF7,Value)
end
Launcher.Game.AwayStrategy = function ()
	return Launcher.Mem.Byte(0x7A949f)
end
Launcher.Game.SetAwayStrategy = function (Value)
	Launcher.Mem.WriteByte(0x7A949f, Value)
end
Launcher.Game.HomeLine = function ()
	return Launcher.Mem.Byte(0x7A4BD0)
end
Launcher.Game.AwayLine = function ()
	return Launcher.Mem.Byte(0x7A4BD4)
end
Launcher.Game.ShootoutRound = function ()
	return Launcher.Mem.Byte(0x79BFB8)
end
Launcher.Game.IsShootout = function()
    if Launcher.Mem.Byte(0x79ba49) == 1 then
        return true
    end
    return false
end
Launcher.Game.ShootoutSide = function()
    return Launcher.Mem.Byte(0x79ba4a)
end
Launcher.Game.ShootoutPlayerID = function()
    return Launcher.Mem.Byte(0x79bc7e)
end
Launcher.Game.PenaltyPendingTeam = function ()
	return Launcher.Mem.Byte(0x79b3f4)
end
Launcher.Game.PenaltyPendingPlayer = function()
	return Launcher.Game.PenaltyPendingTeam() * 20 + Launcher.Mem.Byte(0x79b3f5)
end
Launcher.Game.PenaltyPendingID = function ()
	return Launcher.Mem.Byte(0x79b3f6)
end
Launcher.Game.SetPenaltyPendingID = function (ID)
	Launcher.Mem.WriteByte(0x79b3f6, ID)
end
Launcher.Game.PenaltyPendingTime = function ()
	return Launcher.Mem.Byte(0x79b3f7)*60
end
Launcher.Game.SetPenaltyPendingTime = function (Time)
	Launcher.Mem.WriteByte(0x79b3f7, Time)
end
Launcher.Game.LastGoalTeam = function ()
    return Launcher.Mem.Byte(0x7a4ac4)
end
Launcher.Game.LastGoalPlayer = function ()
    return Launcher.Mem.Byte(0x79c1b4)
end
Launcher.Game.PenaltyTeam = function (Index)
	return Launcher.Mem.Byte(0x79b41c+Index*6)
end
Launcher.Game.PenaltyPlayer = function(Index)
	return Launcher.Mem.Byte(0x79b41c+Index*6) * 20 + Launcher.Mem.Byte(0x79b41d+Index*6)
end
Launcher.Game.PenaltyID = function (Index)
	return Launcher.Mem.Byte(0x79b41e + Index*6)
end
Launcher.Game.PenaltyTime = function (Index)
	return (Launcher.Mem.Byte(0x79b41f + Index*6)*60)
end
Launcher.Game.PenaltyAwayTime = function (Index)
	return Launcher.Mem.Word(0x79b8FC)
end
Launcher.Game.PenaltyHomeTime = function (Index)
	return Launcher.Mem.Word(0x79BB05)
end
function Launcher.Game.PowerplayTime()
   return Launcher.Mem.Short(0x7BD8B0)
end
function Launcher.Game.PowerplayTeam()
   return Launcher.Mem.Byte(0x7BDA64)
end
function Launcher.Game.Warning()
   return Launcher.Mem.Byte(0x79BB05)
end
Launcher.Game.SetArenaFilename = function (Name)
	Launcher.Mem.WriteString(0x72A081,Name)
end
Launcher.Game.ArenaArtID = function(NewValue)
    if NewValue == nil then
        return Launcher.Mem.Byte(0x7a9507)
    else
        Launcher.Mem.WriteByte(0x7a9507,NewValue)
    end
end

Launcher.Game.SetInstantFights = function ()
	local ASM = [[
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
    ]]
    Launcher.Mem.WriteASM(0x4A0E10,ASM)
    Launcher.Mem.WriteASM(0x4A0E35,ASM)

end
function Launcher.Game.PuckZone()
    return Launcher.Mem.Byte(0x7a0f50)
end
function Launcher.Game.PuckZoneTime()
    return Launcher.Mem.Byte(0x7a0f4c)
end
function Launcher.Game.PuckPosition()
    local Address, X, Y, Z
    X = 0
    Y = 0 
    Z = 0
    Address = Launcher.Mem.Long(0x7ad820)
    if Address > 0 then
        Address = Address + 0x110
        Address = Launcher.Mem.Long(Address)
        if Address > 0 then
            Address = Address + 0x1c
            X = Launcher.Mem.Float(Address)
            Y = Launcher.Mem.Float(Address+4)
            Z = Launcher.Mem.Float(Address+8)
        end
    end
    return  X, Y , Z
end
function Launcher.Game.SetPuckPosition(X,Y,Z)
    local Address
    Address = Launcher.Mem.Long(0x7ad820) + 0x110
    Address = Launcher.Mem.Long(Address) + 0x1c
    Launcher.Mem.WriteFloat(Address,X)
    Launcher.Mem.WriteFloat(Address+4,Y)
    Launcher.Mem.WriteFloat(Address+8,Z)
end
Launcher.Game.Over = function()
    local OTMode = Launcher.GameOption.OTMode()
    if OTMode == 5 then -- No overtime or shootout
        if Launcher.Game.Period() == -1 or (Launcher.Game.Period() == 3 and Launcher.Game.Time() == 0) then
            return true
        else
            return false
        end
    elseif OTMode == 3 or OTMode == 4 then -- 4v4 & 5v5 OT
        if (Launcher.Game.Period() == -1) or (Launcher.Game.Period() == 3 and Launcher.Game.Time() == 0 and (Launcher.Stats.AwayGoals() > 0 or Launcher.Stats.HomeGoals() > 0)) then
            return true
        else
            return false
        end
    end
end

Launcher.Game.SetTimer = function(Timer)
    local ASM
    if Timer > 0 then
        ASM = [[
            pop esi
            mov eax,]]..Timer..[[ 
            ret
            nop
        ]]
        Launcher.Mem.WriteASM(0x4a185f,ASM)    
    end
end
Launcher.Game.SetPenaltyTimer = function(PenaltyTimer)
    local ASM
    if PenaltyTimer == 0 then
        ASM = [[
            nop 
            nop 
            nop 
            nop 
            mov eax,[0x79C258]
            mov ecx,[eax]
            movzx edx,byte [ecx+0x000000D6]
            movzx eax,byte [eax+0x000000D6]
            sub eax,edx
            nop 
            nop 
            nop 
            nop 

        ]]
        Launcher.Mem.WriteASM(0x4a1840,ASM)    
    else
        Launcher.Mem.WriteByte(0x4a1870,PenaltyTimer+1)    
    end
    return 1
end
Launcher.Game.SetLastMinuteTimer = function(Timer)
    local ASM
    if Timer == 0 then
        Launcher.Mem.WriteByte(0x4a180b,99)
        return 1
    else
        Launcher.Mem.WriteLong(0x4a1819,Timer)
        return 1
    end
end
Launcher.Game.SetOTTimer = function(OTTimer)
    local ASM, ASMPointer
    if OTTimer == 0 then
        ASM = [[
            nop 
            nop 
            nop 
            nop 
            nop
        ]]  
        Launcher.Mem.WriteASM(0x4a1824,ASM)
        return 1
    else
        ASM = [[
            mov eax, ]]..tostring(OTTimer+1)..[[ 
            pop esi
            ret
        ]]
        ASMPointer = Launcher.Mem.AssembleString(ASM)
        if ASMPointer then
            Launcher.Mem.WriteJump(0x4a187a,ASMPointer)
            Launcher.Mem.WriteByte(0x4a1827,0x74)
            Launcher.Mem.WriteByte(0x4a1828,0x51)
            return 1
        end
    end
    return 0
end
Launcher.Game.SetPuckDropTime = function(Time)
    Launcher.Mem.WriteByte(0x4B218D,Time)
end
Launcher.Game.SetPoints = function(PointsWin, PointsTie,PointsLoseOT, PointsWinOT)
      Launcher.Mem.WriteLong(0x774A74,PointsWin)
      Launcher.Mem.WriteLong(0x774A78,PointsTie)
      Launcher.Mem.WriteLong(0x774A7C,PointsLoseOT)
      Launcher.Mem.WriteLong(0x774A80,PointsWinOT)
end
Launcher.Game.GetLanguage = function()
    return Launcher.Mem.Byte(0x78d348)
end
Launcher.Game.SetLanguage = function(LanguageID)
    Launcher.Mem.WriteByte(0x78d348,LanguageID)
end
Launcher.Game.ArenaName = function()
    return Launcher.Mem.String(0x7A9554,34)
end
Launcher.Game.ArenaLocation = function()
    return Launcher.Mem.String(0x7A9576,24)
end
Launcher.Game.ArenaCapacity = function()
    return Launcher.Mem.Short(0x7A9590)
end
Launcher.Game.ArenaLine = function()
    return Launcher.Mem.Short(0x7A959c)
end
Launcher.Game.ArenaLowerSeats = function()
    return Launcher.Mem.Short(0x7A95a2)
end
Launcher.Game.ArenaMediumSeats = function()
    return Launcher.Mem.Short(0x7A95a3)
end
Launcher.Game.ArenaHigherSeats = function()
    return Launcher.Mem.Short(0x7A95a4)
end
Launcher.Game.ArenaWalls = function()
    return Launcher.Mem.Short(0x7A95a9)
end
Launcher.Game.MusicVolume = function ()
	return Launcher.Mem.Byte(0x78D568)
end
Launcher.Game.HomeFighter = function()
    return Launcher.Mem.Byte(0x79bb34)
end
Launcher.Game.AwayFighter = function()
    return Launcher.Mem.Byte(0x79bb38)+20
end
Launcher.Game.IsFighting = function()
    
    if Launcher.Mem.Byte(0x704a00) == 1 then
        return true
    else
        return false
    end
end

