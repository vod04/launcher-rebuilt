--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]

Launcher.Util = {}
Launcher.Util.FormatTime = function(Time)
    local Minutes = math.floor(Time/60)
    if Minutes < 10 then
        Minutes = "0"..Minutes
    end
    local Seconds = Time % 60
    if Seconds < 10 then
        Seconds = "0"..Seconds
    end
    return Minutes .. ":" .. Seconds
end

Launcher.Util.FormatPlusMinus = function(PlusMinus)
    if PlusMinus < 0 then
        return "-"
    elseif PlusMinus == 0 then
        return "E"
    else
        return "+"
    end
end