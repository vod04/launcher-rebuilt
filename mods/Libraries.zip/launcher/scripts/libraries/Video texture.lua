--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]

Launcher.VideoTexture = {}
Launcher.VideoTexture.Video = {}

Launcher.VideoTexture.Buffer = function(Video)
    local I
    if Video.PrebufferFrame <= Video.Frames then
        for I = 1, Video.PrebufferFrames do
            if Video.PrebufferFrame > Video.Frames then
                return
            end 
            if Video.FrameTexture[I] == nil then
                Video.FrameTexture[I] = Launcher.Texture.Load(Video.Path..tostring(Video.PrebufferFrame).."."..Video.ImageFormat)
                Video.PrebufferFrame = Video.PrebufferFrame + 1
             end
        end
    else
        return
    end
end
Launcher.VideoTexture.ClearBuffer = function(Video)
    local I,Count
    Count = #Video.FrameTexture
    for I = 1,Count do
        Launcher.Texture.Release(table.remove(Video.FrameTexture,1))
    end
end
Launcher.VideoTexture.Load = function(Folder,ImageFormat, Frames, AnimationFPS, FshID)
    local Video, Texture, AudioStream
    if Launcher.Filesystem.DirectoryExists(Folder) then
        
        Texture = Launcher.Texture.Load(Folder.."1."..ImageFormat)
        if Texture == nil then
            return nil
        end
        
        Video = #Launcher.VideoTexture.Video + 1
        Launcher.VideoTexture.Video[Video] = {
            PrebufferFrames = 20,
            BufferInterval = 400,
            PrebufferFrame = 1,
            BufferTime = 0,
            AnimationFPS = AnimationFPS,
            Path=Folder,
            PreviousFrame = 1,
            Frame=1,
            FrameInt=1,
            Frames=Frames,
            FshID = FshID,
            ImageFormat=ImageFormat,
            Volume = 1.0,
            PlayVideo=false,
            Paused = false,
            Width = Launcher.Texture.Width(Texture),
            Height = Launcher.Texture.Height(Texture),
            FrameTexture = {}
        }
        Launcher.Texture.Release(Texture)        

        
		AudioStream = Launcher.Sound.Load(Folder.."track.mp3",false)
		if AudioStream ~= nil then
			Launcher.Sound.SetReverb(AudioStream,BASS_DX8_I3DL2REVERB_lRoom,BASS_DX8_I3DL2REVERB_lRoomHF,BASS_DX8_I3DL2REVERB_flRoomRolloffFactor,BASS_DX8_I3DL2REVERB_flDecayTime,BASS_DX8_I3DL2REVERB_flDecayHFRatio,BASS_DX8_I3DL2REVERB_lReflections,BASS_DX8_I3DL2REVERB_flReflectionsDelay,BASS_DX8_I3DL2REVERB_lReverb,BASS_DX8_I3DL2REVERB_flReverbDelay,BASS_DX8_I3DL2REVERB_flDiffusion,BASS_DX8_I3DL2REVERB_flDensity,BASS_DX8_I3DL2REVERB_flHFReference)
            Launcher.VideoTexture.Video[Video].AudioStream = AudioStream
		end
	else
        return nil
    end
    return Launcher.VideoTexture.Video[Video]
end
Launcher.VideoTexture.CurrentTexture = function(Video)
    return Video.PreviousTexture
end
Launcher.VideoTexture.TotalTime = function(Video)
    return Video.Frames / Video.AnimationFPS
end
Launcher.VideoTexture.ElapsedTime = function(Video)
    return Video.Frame / Video.AnimationFPS
end
Launcher.VideoTexture.Seek = function(Video,Time)
    local Frame
    Frame = Time * Video.AnimationFPS
    Video.Frame = Frame
    Video.FrameInt = math.floor(Frame)
    Video.PrebufferFrame = Video.FrameInt
    if Launcher.AudioStream ~= nil then
        Launcher.Sound.Seek(Video.AudioStream,Time)
    end
end
Launcher.VideoTexture.Stop = function(Video)
    if Video.PlayVideo then
        Launcher.VideoTexture.ClearBuffer(Video)
        Video.PlayVideo = false
        Video.Frame = 1
        Video.FrameInt = 1
        Video.PreviousFrame =1
        Video.PrebufferFrame = 1
        if Video.AudioStream ~= nil then
            Launcher.Sound.Stop(Video.AudioStream)
        end
    end
end

Launcher.VideoTexture.Pause = function(Video)

    if Video.AudioStream ~= nil then
        Launcher.Sound.Pause(Video.AudioStream)
    end
    Video.Paused = true

end

Launcher.VideoTexture.Play = function(Video)
    if Video.Paused == true then
        Video.Paused = false
        if Video.AudioStream ~= nil then
            Launcher.Sound.Play(Video.AudioStream)
        end
        return
    end
    Video.PlayVideo = true
    Video.Frame = 1
    Video.FrameInt = 1
    Video.PreviousFrame = 1
    Video.PrebufferFrame = 1
    Video.Paused = false
    if Video.AudioStream ~= nil then
        Launcher.Sound.Stop(Video.AudioStream)
    end
    Launcher.VideoTexture.ClearBuffer(Video)
    Launcher.VideoTexture.Buffer(Video)
    Video.BufferTime = Launcher.System.Time() + Video.BufferInterval
    Launcher.Sound.SetVolume(Video.AudioStream,Video.Volume)
    Launcher.Sound.Play(Video.AudioStream,true)
    if Video.FshID ~= nil then
        Launcher.Texture.Inject(Video.FrameTexture[FrameInt],Video.FshID)
    end
    Launcher.Video.PreviousTexture = Video.FrameTexture[FrameInt]
    Video.FPSTimer = Launcher.System.Time(2)
end
Launcher.VideoTexture.Release = function(Video)
    local VideoCount,I
    VideoCount = #Launcher.VideoTexture.Video
    for I = 1,VideoCount do
        if Launcher.VideoTexture.Video[I] == Video then
            Launcher.VideoTexture.ClearBuffer(Video)
            if Video.PreviousTexture ~= nil then
                Launcher.Texture.Release(Video.PreviousTexture)
            end
            if Video.AudioStream ~= nil then
                Launcher.Sound.Release(Video.AudioStream)
            end
            table.remove(Launcher.VideoTexture.Video,I)
            return true
        end
    end
    return false
end
Launcher.VideoTexture.ReleaseAll = function()
    local VideoCount, I, Video
    VideoCount = #Launcher.VideoTexture.Video
    for I = 1, VideoCount do
        Video = Launcher.VideoTexture.Video[1]
        Launcher.VideoTexture.ClearBuffer(Video)
        if Video.PreviousTexture ~= nil then
            Launcher.Texture.Release(Video.PreviousTexture)
        end
        if Video.AudioStream ~= nil then
            Launcher.Sound.Release(Video.AudioStream)
        end
        if Video.FshID ~= nil then
            Launcher.Texture.Inject(0,Video.FshID)
        end
        table.remove(Launcher.VideoTexture.Video,1)
    end
end
Launcher.VideoTexture.Tick = function()
    local Time, Delta, Texture, I, Video, Multi, Video,VideoIndex,VideoCount
    VideoCount = #Launcher.VideoTexture.Video
    for VideoIndex = 1, VideoCount do
        Video = Launcher.VideoTexture.Video[VideoIndex]

        if Video.PlayVideo and Video.Paused == false then
            
            if Launcher.System.Time() >= Video.BufferTime then
                Launcher.VideoTexture.Buffer(Video)
                Video.BufferTime = Launcher.System.Time() + Video.BufferInterval
            end
            
            Multi = Launcher.Renderstate.FPSMultiplier(Video.AnimationFPS)
            Video.Frame = Video.Frame + 1*Multi
            if Video.Frame >= Video.Frames then
                Video.Frame = 1
                Video.PlayVideo = false
                Video.FrameInt = 1
                Video.PreviousFrame = 1
                return
            end
            Video.FrameInt = math.floor(Video.Frame)
            if Video.FrameInt ~= Video.PreviousFrame then
                if Video.FrameInt >= Video.PrebufferFrame then
                    Video.PrebufferFrame = Video.FrameInt
                    Video.PreviousFrame = Video.FrameInt
                    Launcher.VideoTexture.ClearBuffer(Video)
                    Launcher.VideoTexture.Buffer(Video)
                    return
                end
                if #Video.FrameTexture == 0 then
                    return
                end
                for I = 1,(Video.FrameInt-Video.PreviousFrame) do
                    if #Video.FrameTexture == 0 then
                        return
                    end
                    Texture = table.remove(Video.FrameTexture,1)
                    if I < (Video.FrameInt-Video.PreviousFrame) then
                        Launcher.Texture.Release(Texture)
                    end
                end
                if Video.PreviousTexture ~= nil then
                    Launcher.Texture.Release(Video.PreviousTexture)
                end
                Video.PreviousTexture = Texture
                Video.PreviousFrame = Video.FrameInt
                if Video.FshID ~= nil then
                    Launcher.Texture.Inject(Texture,Video.FshID)
                end              
            end
        end
    end
end