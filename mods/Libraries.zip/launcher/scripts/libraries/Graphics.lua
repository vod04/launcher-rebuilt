--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]

Launcher.Graphics = {}
Launcher.Graphics.SetPlayerShadowCount = function (Count)
	return Launcher.Mem.WriteByte(0x776D8C,Count)
end
Launcher.Graphics.PlayerShadowCount = function ()
	return Launcher.Mem.Byte(0x776D8C)
end
Launcher.Graphics.SetPlayerShadowColor = function(Color)
    Launcher.Mem.WriteFloat(0x776d94,Red(Color)/255)
    Launcher.Mem.WriteFloat(0x776d98,Green(Color)/255)
    Launcher.Mem.WriteFloat(0x776d9c,Blue(Color)/255)
    Launcher.Mem.WriteFloat(0x776DA0,Alpha(Color)/255)
end
Launcher.Graphics.PlayerShadowRed = function ()
	return Launcher.Mem.Float(0x776d94)
end
Launcher.Graphics.PlayerShadowGreen = function ()
	return Launcher.Mem.Float(0x776d98)
end
Launcher.Graphics.PlayerShadowBlue = function ()
	return Launcher.Mem.Float(0x776d9c)
end
Launcher.Graphics.PlayerShadowAlpha = function ()
	return Launcher.Mem.Float(0x776DA0)
end

Launcher.Graphics.SetPlayerShadowOffset = function (Offset)
	return Launcher.Mem.WriteFloat(0x776D84,Offset)
end
Launcher.Graphics.PlayerShadowOffset = function ()
	return Launcher.Mem.Float(0x776D84)
end
Launcher.Graphics.EnablePuckShadow = function (Enable)
	return Launcher.Mem.WriteByte(0x78D5F4,Enable)
end

Launcher.Graphics.PuckShadowEnabled = function ()
	if Launcher.Mem.Byte(0x78D5F4) == 0 then
		return false
	else
		return true
	end
	
end

Launcher.Graphics.SetPuckShadowSize = function (Size)
	return Launcher.Mem.WriteFloat(0x6F5140,Size)
end

Launcher.Graphics.PuckShadowSize = function ()
	return Launcher.Mem.Byte(0x6F5140)
end

Launcher.Graphics.EnablePlayerShadows = function (Enable)
	return Launcher.Mem.WriteByte(0x7768d0,Enable)
end
Launcher.Graphics.EnablePlayerReflections = function (Enable)
	return Launcher.Mem.WriteByte(0x7768e4,Enable)
end
Launcher.Screen.D3DDevice = function ()
	return Launcher.Mem.Long(0x7D08A8)
end