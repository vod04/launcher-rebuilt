--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]


Launcher.Physics = {}

Launcher.Physics.SetPuckGravity = function (Gravity)
	Launcher.Mem.WriteFloat(0x79C754, Gravity)
end
Launcher.Physics.PuckGravity = function ()
	return Launcher.Mem.Float(0x79C754)
end
Launcher.Physics.SetPuckBounceFriction = function (Friction)
	Launcher.Mem.WriteFloat(0x79C768, Friction)
end
Launcher.Physics.SetPuckBoardBounceFriction = function (Friction)
	Launcher.Mem.WriteFloat(0x79C76C, Friction)
end
Launcher.Physics.SetPuckBoardFriction = function (Friction)
	Launcher.Mem.WriteFloat(0x79C774, Friction)
end
Launcher.Physics.SetPlayerBaseSpeed = function(Speed)
    Launcher.Mem.WriteFloat(0x79c3f0,Speed)
end
Launcher.Physics.SetPlayerUpperSpeed = function(Speed)
    Launcher.Mem.WriteFloat(0x79c3ec,Speed)
end
Launcher.Physics.SetPlayerSpeedMultiplier = function(Speed)
    Launcher.Mem.WriteFloat(0x79c3e8,Speed)
end
Launcher.Physics.SetHomePlayerSpeedMultiplier = function(Speed)
    Launcher.Mem.WriteFloat(0x79C840,Speed)
end
Launcher.Physics.SetAwayPlayerSpeedMultiplier = function(Speed)
    Launcher.Mem.WriteFloat(0x79C844,Speed)
end
Launcher.Physics.SetPlayerSpeedBoostMultiplier = function(Speed)
    Launcher.Mem.WriteFloat(0x79C3F4,Speed)
end
Launcher.Physics.SetPassBaseSpeed = function(Speed)
    Launcher.Mem.WriteFloat(0x79c700,Speed)
end
Launcher.Physics.SetPassUpperSpeed = function(Speed)
    Launcher.Mem.WriteFloat(0x79c704,Speed)
end
Launcher.Physics.SetGoaliePassSpeedMultiplier = function(Speed)
    Launcher.Mem.WriteFloat(0x79c730,Speed)
end
Launcher.Physics.SetSaucerPassSpeedMultiplier = function(Speed)
    Launcher.Mem.WriteFloat(0x79c728,Speed)
end
Launcher.Physics.SetPlayerSpeedEnergyMultiplier = function(Speed)
    Launcher.Mem.WriteFloat(0x709f90,Speed)
end