--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]


ASM = [[ 
    **RenderBackground
	mov eax, 0x54FB10
	call eax
    ret 
]]
function RenderBackground()
	Launcher.Screen.BeginScene()
	Launcher.Callback.Trigger("RenderBackground", nil, nil)
	Launcher.Screen.EndScene()
end
if Launcher.Callback.Create("RenderBackground") ~= nil then
    ASMPointer = Launcher.Mem.AssembleString(ASM)
    if ASMPointer ~= nil then
        Launcher.Mem.WriteCall(0x59c52c,ASMPointer)
    end
end

