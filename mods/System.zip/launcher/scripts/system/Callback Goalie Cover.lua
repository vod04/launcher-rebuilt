Address = Launcher.Mem.Alloc(4)
ASM = [[ 
    **GoalieCover
    mov ecx,[]]..Address..[[] 
    ret 
]]
function GoalieCover()
    local Count
    Count = Launcher.Callback.Count("GoalieCover")-1
    if Count > 0 then
        for I = 0,Count do 
            Ret = Launcher.Callback.Trigger("GoalieCover",nil,I)
            if Ret ~= nil and Ret then
                Launcher.Mem.WriteByte(Address,1)
                return
            else
                Launcher.Mem.WriteByte(Address,0)
            end
        end
    else
        if Launcher.Game.PuckPossessionTime() >= Launcher.Game.GoalieCoverTime() then
            Launcher.Mem.WriteByte(Address,1)
        else
            Launcher.Mem.WriteByte(Address,0)
        end
    end
end
if Launcher.Callback.Create("GoalieCover") ~= nil then
    ASMPointer = Launcher.Mem.AssembleString(ASM)
    if ASMPointer ~= nil then
        Launcher.Mem.WriteCall(0x4b4c19,ASMPointer,1)
        ASM = [[
           cmp ecx,1
           nop
           nop
           nop
        ]]
        Launcher.Mem.WriteASM(0x4b4c1f,ASM)
        Launcher.Mem.WriteByte(0x4b4c25,0x75)
    end
end
