Icing = Launcher.Config.Int("Icing",0)
if Icing == 1 then
    Launcher.Mem.WriteByte(0x4b48eb,0xeb)
end