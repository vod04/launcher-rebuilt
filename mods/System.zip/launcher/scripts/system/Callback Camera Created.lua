--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]
LastCameraPointer = 0
Pointer = Launcher.Mem.Alloc(4)
Launcher.Mem.WriteLong(Pointer,	0x555750)
ASM = [[ 
    mov byte [0x7ACB10],00
    **CameraCreated
    ret 
]]
function CameraCreated()
	local CameraPointer
	CameraPointer = Launcher.Mem.Long(0x7ACA04)
	if CameraPointer ~= LastCameraPointer then
		LastCameraPointer = CameraPointer
		Launcher.Callback.Trigger("CameraCreated",nil,nil)
	end
end
if Launcher.Callback.Create("CameraCreated") ~= nil then
    ASMPointer = Launcher.Mem.AssembleString(ASM)
    if ASMPointer ~= nil then
        Launcher.Mem.WriteCall(0x53CCDB,ASMPointer,2)
    end
end

