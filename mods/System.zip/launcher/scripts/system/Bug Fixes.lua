--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]

Launcher.Mem.WriteByte(0x4a186c,6) -- Fixes timing bug in EA's code

-- Fix RNG
CountAddress = Launcher.Mem.Alloc(4)
SeedAddress = Launcher.Mem.Alloc(4)
Launcher.Mem.WriteLong(SeedAddress,os.time())
Launcher.Mem.WriteByte(CountAddress,0)
ASM = [[
		cmp dword[]]..CountAddress..[[], 2
		JG finished
			inc dword []]..CountAddress..[[] 
			mov ecx, dword []]..SeedAddress..[[] 
			imul ecx,ecx,0x000343FD
			ret
		finished:
			mov ecx, dword [eax+0x14]
			imul ecx,ecx,0x000343FD
			ret
	]]
ASMPointer = Launcher.Mem.AssembleString(ASM)
Launcher.Mem.WriteCall(0x6807e4,ASMPointer,4)